sudo python Worm.py
